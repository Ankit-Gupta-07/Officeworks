package ainvi.overriding;

public class arith {
    public void sum(int a,int b){
        int c=a+b;
        System.out.println("SUm first class :"+c);
    }

}
